import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class EmployeeExec {
	
	
	public static void main(String[] args) {
	
		ApplicationContext ctx = new ClassPathXmlApplicationContext("jdbc.xml");
		EmployeeDAO empDao = (EmployeeDAO)ctx.getBean("employeeDao");
		Employee employee = new Employee();
		employee.setEmployeeName("Robert");
		employee.setEmployeeDept("airforce");
		employee.setEmailId("sam@airforce.org");
		
		empDao.saveEmployee(employee);
		
		//getting the data 
		Employee emp = empDao.getEmploye(5);
		
		System.out.println("Employee name :"+emp.getEmployeeName());
		System.out.println("Employee email :"+emp.getEmailId());
		System.out.println("Employee department:"+emp.getEmployeeDept());
		
		
	}

}
